import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import { enrollInCourse } from '../../store/slices/courseSlice';
import './EnrollButton.css';

const EnrollButton = ({ courseId, isEnrolled }) => {
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const { error } = useSelector(state => state.courses);

  const handleEnroll = async () => {
    setLoading(true);
    await dispatch(enrollInCourse(courseId));
    setLoading(false);
  };

  if (isEnrolled) {
    return <button className="btn btn-secondary enrolled-btn" disabled>Enrolled</button>;
  }

  return (
    <div className="enroll-container">
      <button 
        className="btn btn-primary enroll-btn" 
        onClick={handleEnroll} 
        disabled={loading}
      >
        {loading ? 'Enrolling...' : 'Enroll Now'}
      </button>
      {error && <p className="enroll-error">{error}</p>}
    </div>
  );
};

EnrollButton.propTypes = {
  courseId: PropTypes.number.isRequired,
  isEnrolled: PropTypes.bool.isRequired
};

export default EnrollButton;
