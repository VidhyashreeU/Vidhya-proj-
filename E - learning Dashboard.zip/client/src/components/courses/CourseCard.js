import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import './CourseCard.css';

const CourseCard = ({ course }) => {
  return (
    <div className="course-card">
      <div className="course-image">
        <img src={course.imageUrl || '/default-course.jpg'} alt={course.title} />
      </div>
      <div className="course-content">
        <h3 className="course-title">{course.title}</h3>
        <p className="course-description">{course.description}</p>
        <div className="course-meta">
          <span className="course-instructor">Instructor: {course.instructor}</span>
          <span className="course-duration">Duration: {course.duration}</span>
        </div>
        <div className="course-footer">
          <Link to={`/courses/${course.id}`} className="btn btn-primary">View Course</Link>
        </div>
      </div>
    </div>
  );
};

CourseCard.propTypes = {
  course: PropTypes.shape({
    id: PropTypes.number.isRequired,
    title: PropTypes.string.isRequired,
    description: PropTypes.string.isRequired,
    imageUrl: PropTypes.string,
    instructor: PropTypes.string.isRequired,
    duration: PropTypes.string.isRequired
  }).isRequired
};

export default CourseCard;