import React from 'react';
import PropTypes from 'prop-types';
import './QuizQuestion.css';

const QuizQuestion = ({ question, selectedAnswer, onSelectAnswer }) => {
  return (
    <div className="quiz-question">
      <h3 className="question-text">{question.question}</h3>
      <div className="answer-options">
        {question.options.map((option, index) => (
          <div 
            key={index} 
            className={`answer-option ${selectedAnswer === option ? 'selected' : ''}`}
            onClick={() => onSelectAnswer(option)}
          >
            <span className="option-letter">{String.fromCharCode(65 + index)}</span>
            <span className="option-text">{option}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

QuizQuestion.propTypes = {
  question: PropTypes.shape({
    id: PropTypes.number.isRequired,
    question: PropTypes.string.isRequired,
    options: PropTypes.arrayOf(PropTypes.string).isRequired
  }).isRequired,
  selectedAnswer: PropTypes.string,
  onSelectAnswer: PropTypes.func.isRequired
};

export default QuizQuestion;