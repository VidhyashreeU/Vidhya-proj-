﻿ namespace CapstoneProjectCoreAPI.Models
    {
        public class Question
        {
            public int Id { get; set; }
            public required string Text { get; set; }

            // Answer options
            public required string OptionA { get; set; }
            public required string OptionB { get; set; }
            public required string OptionC { get; set; }
            public required string OptionD { get; set; }

            public required string CorrectAnswer { get; set; }
            // Foreign key - Links question to a quiz
            public int QuizId { get; set; }
            public required Quiz Quiz { get; set; }
        }
    }

